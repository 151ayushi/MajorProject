<?php
session_start();

?>

<!DOCTYPE html>
<html>

<head>
	<title>SkillBoost</title>
	<link rel="stylesheet" type="text/css" href="css/programming.css">
	<link rel="shortcut icon" type="text/css" href="img/logo2.png" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		.context-dark,
		.bg-gray-dark,
		.bg-primary {
			color: rgba(255, 255, 255, 0.8);
		}

		.footer-classic a,
		.footer-classic a:focus,
		.footer-classic a:active {
			color: #ffffff;
		}

		.nav-list li {
			padding-top: 5px;
			padding-bottom: 5px;
		}

		.nav-list li a:hover:before {
			margin-left: 0;
			opacity: 1;
			visibility: visible;
		}

		ul,
		ol {
			list-style: none;
			padding: 0;
			margin: 0;
		}

		.social-inner {
			display: flex;
			flex-direction: column;
			align-items: center;
			width: 100%;
			padding: 23px;
			font: 900 13px/1 "Lato", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
			text-transform: uppercase;
			color: rgba(255, 255, 255, 0.5);
		}

		.social-container .col {
			border: 1px solid rgba(255, 255, 255, 0.1);
			display: inline-block;
		}

		.nav-list li a:before {
			content: "\f14f";
			font: 400 21px/1 "Material Design Icons";
			color: #4d6de6;
			display: inline-block;
			vertical-align: baseline;
			margin-left: -28px;
			margin-right: 7px;
			opacity: 0;
			visibility: hidden;
			transition: .22s ease;
		}

		.div1 {
			margin-top: 0;
			position: relative;
			height: 700px;
			
			width: 100%;
			/* background: url(uploadimg/programming_image.png); */
			background: url(img/course.webp);
			background-size: cover;
		}
	</style>
</head>

<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navi">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h1 style="color: white;margin-top: 10px;" id="myhead">SkillBoost</h1>
			</div>
			<div class="collapse navbar-collapse" id="navi">
				<ul class="nav navbar-nav navbar-right">
					<li> <a href="index.php">Home</a></li>
					<li> <a href="">About</a></li>
					<li> <a href="#latest">Courses</a></li>
					<li> <a href="" id="our-location" class="btn-success"><?php echo $_SESSION['username']; ?></a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!---Navigation Ends	----->
	<div class="container-fluid  div1">

	</div>
	<!---programming languages Section Start----->

	<section class="latest-news-area" id="latest">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h2><b>VAC Courses</b></h2>
						<div class="sub-heading " style="margin-bottom: 4px;">
							Following are the available Courses<br>
							Start learning today
						</div>
					</div>
				</div>
			</div>
			
			<?php
			$con = mysqli_connect('localhost:3307', 'root');
			mysqli_select_db($con, 'uniq');
			$q = "select * from programming_languages";
			$query = mysqli_query($con, $q);
			while ($res = mysqli_fetch_array($query)) {
			?>
				<div class="col-md-4 col-sm-6 col-xs-12 content-border" style="margin-bottom: 10px;">
					<div class="latest-news-wrap">
						<div class="news-img">
							<img src=<?php echo $res['language_image']; ?> class="img-responsive">
							<div class="deat" style="height: auto;">
								<span ><?php echo $res['language_name']; ?></span>
							</div>
						</div>
						<div class="news-content" style="margin: 10px;">
							<p>
								<?php echo $res['language_description']; ?>
							</p>
							<a  href="programming/java/java_programming.php?course_name=<?php echo $res['language_name'] ?>">Start Reading...</a>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
	</section>
	<!---programming languages Section ends	----->
	<!---footer Section Start	----->

	<!-- <br><br><br><br> -->

	<footer class="section footer-classic context-dark bg-image " style="background: #34495e ;color: white;">
		<div class="container">
			<div class="row row-30">
				<div class="col-md-4 col-xl-5">
					<div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="img/sgvulogo.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x" style="margin: 20px;"></a>
						<p style="color: white;">An outstanding learning center devoted to learners who desire to explore is <b> SkillBoost. </b></p>
						<!-- Rights-->
						<p class="rights"><span>©  </span><span class="copyright-year">2023</span><span> </span><span>SkillBoost</span><span>. </span><span>All Rights Reserved.</span></p>
					</div>
				</div>
				<div class="col-md-4">
					<h5>Contacts</h5>
					<dl class="contact-list">
						<dt>Address:</dt>
						<dd>SGVU, JagatPura, Jaipur</dd>
					</dl>
					<dl class="contact-list">
						<dt>email:</dt>
						<dd><a href="mailto:#">sgvu@gmail.com</a></dd>
					</dl>
					<dl class="contact-list">
						<dt>phones:</dt>
						<dd><a href="tel:#">+91 8989898989</a> <span>or</span> <a href="tel:#">+91 5665566556</a>
						</dd>
					</dl>
				</div>
				<div class="col-md-4 col-xl-3">
					<h5>Links</h5>
					<ul class="nav-list">
						<li><a href="#">About</a></li>
						<li><a href="#">Projects</a></li>
						<li><a href="#">Blog</a></li>
						<li><a href="#">Contacts</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="social-networks text-center " >
					<a href="https://www.facebook.com/sureshgyanviharuniversityjaipur/" class="fa fa-facebook" style="margin-bottom: 10px; margin-left:5px"></a>
					<a href="https://twitter.com/gyan_vihar" class="fa fa-twitter" style="margin-bottom: 10px; margin-left:5px"></a>
					<a href="https://www.instagram.com/gyanvihar.university/" class="fa fa-instagram" style="margin-bottom: 10px; margin-left:5px"></a>
					<a href="https://www.gyanvihar.org/" class="fa fa-google" style="margin-bottom: 10px; margin-left:5px"></a>
					<a href="https://www.linkedin.com/school/suresh-gyan-vihar-univeristy-jaipur/" class="fa fa-linkedin" style="margin-bottom: 10px; margin-left:5px"></a>
					
				</div>
		
	</footer>

	
</body>

</html>