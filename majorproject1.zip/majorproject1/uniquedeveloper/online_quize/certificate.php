<?php
session_start();
if (!isset($_SESSION['username'])) {
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

 <style type='text/css'>
            body, html {
                margin-left:13%;
                margin-top: 3%;
                padding: 0;
            }
            body {
                color: black;
                display: table;
                font-family: Georgia, serif;
                font-size: 24px;
                text-align: center;
            }
            .container {
                border: 20px solid tan;
                width: 750px;
                height: 563px;
                display: table-cell;
                vertical-align: middle;
            }
            .logo {
                color: tan;
            }

            .marquee {
                color: tan;
                font-size: 48px;
                margin: 20px;
            }
            .assignment {
                margin: 20px;
            }
            .person {
                border-bottom: 2px solid black;
                font-size: 32px;
                font-style: italic;
                margin: 20px auto;
                width: 400px;
            }
            .course {
                /* border-bottom: 2px solid black; */
                font-size: 32px;
                text-decoration: none;
                font-style: italic;
                margin: 20px auto;
                width: 400px;
            }
            .reason {
                margin: 20px;
            }
        </style>


<body >
<div class="container">
            <div class="logo">
                An Organization
            </div>

            <div class="marquee">
                Certificate of Completion of
            </div>
            <div class="course">
                Ethical Hacking
            </div>


            <div class="assignment">
                This certificate is presented to
            </div>

            <div class="person">
           <?php echo $_SESSION['username'];   ?>
                <!-- Joe Nathan -->
            </div>

            <div class="reason">
                For deftly defying the laws of gravity<br/>
                and flying high
            </div>
        </div>

  
   </body>

</html>